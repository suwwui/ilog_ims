<?php
/*
|--------------------------------------------------------------------------
| i-LOG-INV 
|--------------------------------------------------------------------------
| Author: NFW
| Project Name: i-LOG fyp 21/22
| Offcial page: http://ilogims.online/
| 
|
*/
  define( 'DB_HOST', 'localhost' );          // Set db host
  define( 'DB_USER', 'root' );             // Set db user
  define( 'DB_PASS', '' );             // Set db password
  define( 'DB_NAME', 'ims_fyp' );        // Set db name

?>
